print("Hello, world")

