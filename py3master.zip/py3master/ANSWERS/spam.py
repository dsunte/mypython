print("SPAM SPAM SPAM!")
