for n in range(0, 32):
    print("{:2d} {:10d}".format(n, 2**n))

