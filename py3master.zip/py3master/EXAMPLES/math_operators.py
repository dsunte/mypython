a = 23
b = 7

print(a + b, a - b, a * b)

print(a / b, a // b, a / -b, a // -b)

print(a ** b)

print(a % b)

x = 22
x += 10  # Same as x = x + 10
print(f"x: {x}")

