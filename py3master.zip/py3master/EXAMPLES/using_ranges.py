
print("range(1, 6): ", end=' ')
for x in range(1, 6):  # Start=1, Stop=6 (1 through 5)
    print(x, end=' ')
print()

print("range(6): ", end=' ')
for x in range(6):  # Start=0, Stop=6 (0 through 5)
    print(x, end=' ')
print()

print("range(3, 12): ", end=' ')
for x in range(3, 12):  # Start=3, Stop=12 (3 through 11)
    print(x, end=' ')
print()

print("range(5, 30, 5): ", end=' ')
for x in range(5, 30, 5):  # Start=5, Stop=30, Step=5 (5 through 25 by 5)
    print(x, end=' ')
print()

print("range(10, 0, -1): ", end=' ')
for x in range(10, 0, -1):  # Start=10, Stop=1, Step=-1 (10 through 1 by 1)
    print(x, end=' ')
print()
