a = "123"
b = 456
result = a + b  # raises error due to incompatible types

